<div align="center">

# 👀 Starryear-EyeEye｜可可爱爱眼眼睛睛

**上方保留原图证据，下方让真实色块醒来，合成一张低超现实的 9:16 竖版拼贴。**

![Codex Skill](https://img.shields.io/badge/Codex-Skill-000000?style=for-the-badge&logo=openai&logoColor=white)
[![Usage](https://img.shields.io/badge/Usage-Personal%20%26%20Non--commercial-lightgrey?style=for-the-badge)](./LICENSE.md)
![Language](https://img.shields.io/badge/🌐_中文-English-blue?style=for-the-badge)

</div>

---

## ⚠️ 声明

> **仅限个人学习、非营利研究与非商业创作。**
> 任何商业使用均须事先取得 Starryear年 的书面许可。
>
> 分享作品时，欢迎标注来源并 **@Starryear年**。

---

## 📖 关于本项目

Starryear-EyeEye 以一张照片为唯一内容与色彩证据，制作一张竖版 9:16 拼贴：上部原图仅允许裁切、缩放和排版，保持像素内容不变；下部把真实轮廓、光影、褶皱与负空间转译为水彩纸上的柔软生命。超现实程度保持低，只用一两处克制的尺度、透明或重力变化制造轻微异感。

- ✅ 保留原图的空间、动势、光线、色温与材料线索
- ✅ 严格执行“一块＝一只＝一对眼睛”，最终只输出一张 9:16 竖图
- ❌ 不做机械贴眼滤镜，不复制参考图，也不凭空添加无关角色

> 📝 The Skill includes the complete prompt in both **Chinese** and **English**.

---

## 🖼️ 示例作品

> 测试通过后补充。当前 `assets/examples/` 保持为空，不放置参考图、测试图或临时生成图。

---

## 📋 目录

- [使用方法](#-使用方法)
- [可自由调整的部分](#️-可自由调整的部分)
- [核心原则](#-核心原则)
- [内容结构](#-内容结构)
- [许可证](#-许可证)

---

## 🚀 使用方法

### 方式一：作为 Codex Skill 使用

1. 将整个 `starryear-eyeeye-surreal` 文件夹放入 Codex skills 目录，例如 `~/.codex/skills/`。
2. 开启新的 Codex 对话并上传一张原始照片；画风参考图可选。
3. 提出需求：

   > 使用 `starryear-eyeeye-surreal`，把这张照片变成稍微更超现实的眼睛生命群落。

4. 默认输出一张 9:16 竖版成品；上图通常占 27%—38%，并在合成前为下图确定安全区，确保主体与底部内容完整可见。

### 方式二：作为提示词直接使用

| 语言 | 文件 |
| :---: | :--- |
| 🇨🇳 中文 | [references/starryear-eyeeye-surreal-prompt.zh-CN.md](references/starryear-eyeeye-surreal-prompt.zh-CN.md) |
| 🇬🇧 English | [references/starryear-eyeeye-surreal-prompt.en.md](references/starryear-eyeeye-surreal-prompt.en.md) |

---

## 🎛️ 可自由调整的部分

| 参数 | 说明 |
| :--- | :--- |
| **超现实强度** | 默认低；只允许一至两处轻微尺度、透明、连续性或重力变化 |
| **生命密度** | 可在疏朗、平衡、密集间调整，但每只仍需独立可辨 |
| **眼神气质** | 可偏困倦、好奇、害羞或出神，始终克制且不做夸张表演 |
| **上下占比** | 上方原图通常占 27%—38%；优先保证选定的下方作品完整可见，必要时用同色纸面向两侧延展 |

---

## 💡 核心原则

1. **证据生长** — 每个主要形体、色彩与动势都能追溯到原照片。
2. **一块一命一双眼** — 每只生命独立完整，有且只有一对极简眼睛。
3. **关系超现实** — 通过尺度、深度、透明度、连续性和重力制造异感，而非堆砌奇物。
4. **证据不重构** — 上方原图只裁切、缩放和放置，不重绘、不补画、不加滤镜。

---

## 📁 内容结构

```text
starryear-eyeeye-surreal/
├── README.md
├── LICENSE.md
├── SKILL.md
├── agents/openai.yaml
├── references/
│   ├── starryear-eyeeye-surreal-prompt.zh-CN.md
│   └── starryear-eyeeye-surreal-prompt.en.md
└── assets/examples/
```

> ⚠️ 初版测试包中的 `assets/examples/` 必须为空。仅在 Starryear年 确认测试通过后，加入其提供或明确认可的最终成品图；不得放入参考图、测试图或临时输出。

---

## 📄 许可证

本项目采用 [LICENSE.md](./LICENSE.md) 中规定的使用条款。

---

<div align="center">

**如果这个项目对你有帮助，欢迎 Star ⭐ 支持！**

</div>
