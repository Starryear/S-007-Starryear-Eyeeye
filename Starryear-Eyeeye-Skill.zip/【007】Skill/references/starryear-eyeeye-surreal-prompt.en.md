# Starryear-EyeEye Full Prompt

Treat one user-supplied photograph as both immutable photographic evidence and the sole content, compositional, and color source for the generated region. Create one flattened vertical 9:16 collage: a crop-only, unchanged original photograph above and a low-surreal watercolor habitat of EyeEye creatures derived from that same photograph below. Do not redraw the upper photograph or turn the whole image into a filter effect.

## 1. Role of the input image

- The original photograph is the only content and color source. An optional style reference may contribute only abstract traits such as hazy watercolor, translucent layers, soft organic masses, powdery mist, minimal paired eyes, and a quiet collective atmosphere.
- Never copy a style reference's characters, composition, colors, text, logo, signature, or watermark.
- Preserve the pixel content of the upper evidence panel. Permit only cropping, proportional scaling, and placement. Do not repaint, stylize, filter, retouch, generatively extend, remove, replace, add eyes to, or paint over any part of it.
- Cropping is allowed for the 9:16 layout, but prioritize the subject, visual center, main direction, and decisive spatial relations. Never stretch the image.

## 2. Internal observation method

Make these judgments internally and output no analysis:

1. Identify three to six decisive visual facts: subject mass, main direction, light-dark flow, spatial hierarchy, material behavior, color temperature, and local accent colors.
2. Consolidate independently contoured objects, color fields, folds, shadows, and negative spaces into legible large, medium, and small masses. Compress debris instead of copying noise point by point.
3. Decide which masses can become independent creatures and preserve their relative position, occlusion, scale, density, and motion in the lower world.
4. Select no more than one or two low-intensity surreal relations: mild scale drift, translucent passage, gentle suspension, slight depth folding, or one source-derived form dissolving across the transition. Do not stack every effect.
5. Identify the photograph's focal subjects, such as fruit, flowers, stones, objects, or animal silhouettes. Translate them into the shared watercolor creature language while preserving enough geometry, clustering, surface grain, and visual weight to recognize the prototype; retain no photorealistic fragment.

## 3. Vertical collage and canvas

- Fix the final canvas to vertical 9:16 and return one finished image only.
- The upper photograph normally occupies 27–38% of total height and the lower work uses the remainder. Calculate the final lower dimensions and safe area before generation; never compose a standalone portrait first and then crop away its subject during assembly.
- Keep the upper region unmistakably photographic and the lower region unmistakably generated watercolor on paper. Do not treat them as a comparison diptych and add no frame, divider, or title band.
- Use a soft collage transition such as a torn paper edge, thin mist, pigment bleed, or a few source-derived masses beginning below the boundary. Generated content must not cover or falsify pixels inside the photograph.
- Share the source's main direction, visual center, and color flow across both regions. The lower world should feel distilled from the evidence above, not pasted in as an unrelated illustration.
- Keep focal fruit, complete bodies, eyes, and narrative interactions inside the final visible safe area. Reserve any crop-prone bottom zone for paper, mist, loose foliage, and nonessential detail only.
- If the user has selected an existing full vertical artwork as the definitive lower image, scale it proportionally so the entire artwork fits. When it is narrower than the reserved panel, extend only its peripheral paper, color haze, or subject-free texture sideways. Never crop its bottom, fruit, or creatures merely to fill width.
- Preserve breathing room. Density may gather around the main subject and loosen toward the perimeter; avoid equal height, equal spacing, or lineup staging.
- Prioritize beauty and cuteness while establishing a clear hierarchy. If the source has an obvious subject, translate it into the unmistakable first read below: enlarge it clearly without choking the frame, and let secondary creatures become smaller, lighter, and airier. Create tension through focal scale contrast, diagonal or arcing movement, cluster spacing, and exchanged gazes; avoid heavy black masses and oppressive density.

## 4. Soft creature reconstruction

- Every lower creature must derive from visible evidence in the photograph and retain its source form's directional, material, and spatial role.
- Enforce: one mass = one creature = one pair of eyes.
- Each creature is a complete, independently readable soft mass. Each body has exactly one pair of eyes, and every independent creature must have eyes, including pale, translucent, partially hidden, background, and edge creatures.
- Prohibit one continuous body with multiple eye pairs, floating eyes without bodies, independent eyeless creatures, mechanically pasted eyes on a continuous surface, or cloned characters.
- The focal source subject must become fully alive. When fruit is focal, choose one fruit or cluster as the clear hero of the generated region and enlarge it substantially. Cartoonize the entire fruit into a semi-cartoon watercolor being without retaining photographic fragments. Preserve roundness, clustered suspension, irregular size variation, scale-like segmented facets, skin seams and wrinkles, dry-brush breaks, granular sediment, and warm highlights. Hold recognition and abstraction in balance: neither a cut-out literal fruit nor a generic smooth sphere.
- Body silhouettes must answer their prototypes: fruit may remain round, while feathery foliage becomes plume-shaped, elongated, branching, trailing, curled, or tapered-drop creatures. Never force all beings into identical circles or capsules.

## 5. Eyes and expression

- Give each creature only two small dark handmade pigment marks. Add no mouth, nose, eyebrows, sclera, constructed pupils, eyelashes, or complete face.
- Keep eye size within roughly 70–130% of the group average. Vary size, spacing, darkness, height, and openness with restraint in response to body volume, tilt, transparency, material, and depth.
- Mix soft dots, slightly flattened ovals, and a very small number of short horizontal marks. A few may sit beneath a translucent watercolor veil. Expressions are limited to quiet curiosity, sleepiness, shyness, calm attention, distant reverie, or mild surprise.
- Make eye diversity visibly legible in the finished work: distribute round dots, flat ovals, closed short dashes, low half-closed marks, slight high-low pairs following body tilt, and veiled pale pairs. Do not allow identical upright dots to dominate the population.
- Avoid identical black dots, exaggerated cartoon acting, comic mismatched eyes, and realistic eyeballs.

## 6. Low-surreal control

- Surrealism changes relations among source-derived forms and never introduces unrelated objects. Use one or two of the following by default: slight scale displacement, transparent bodies passing through one another, softened gravity, mildly folded depth, or a form turning impossibly while continuing through mist.
- Every mutation must trace to a source shape, light path, or motion. Keep the amplitude gentle: the image should feel fresh, quiet, and poetic first, and only slightly uncanny second.
- Exclude portals, outer space, tentacles, giant eyeballs, monsters, gore, frightening faces, unsupported buildings, props, and other high-intensity spectacle.

## 7. Boundaries, material, and surface

- Render the lower area as handmade watercolor, pastel bloom, and dry pigment on paper: wet diffusion, powdery particles, fine sediment, translucent layers, misty transitions, and subtly uneven fibers.
- Keep every creature boundary soft and natural. Allow feathering, dissolution, translucent overlap, and paper absorption. Separate neighboring forms through small value shifts, transparent color overlap, narrow breathing gaps, and temperature changes.
- Exclude hard outlines, carved contours, jagged edges, heavy glow, relief, vector edges, cut-paper division, plastic toys, glossy 3D, strong vignettes, scan grime, compression artifacts, and repeating textures.

## 8. Color and light

- Derive every color from the photograph's dominant hues, light color, shadow color, and local accents. A style reference never supplies the palette.
- Default to medium-high watercolor concentration: preserve luminous apricot, persimmon orange, orange-red, cinnamon shadows, and deep-brown accents. Use transparent layering and selected dense pigment pools for vivid depth; paper color provides breathing room but must not wash the scene into pale beige.
- Preserve the photograph's warm-cool balance and primary light direction. You may soften oppressive pure blacks and harsh contrast using pale, misty, or paper-like colors already supported by the photograph.
- Do not impose cool gray, mist blue, lavender, neon, rainbow pastel, or any fashionable palette that conflicts with the source.

## 9. Text and content limits

- Include no text, numbers, dates, titles, logos, signatures, watermarks, borders, or panel dividers.
- Invent no people, hands, realistic animals, or unrelated props. If such content already appears in the source, preserve it unchanged above; below, translate only its visual mass into a non-realistic soft form without reproducing identity or a realistic face.

## 10. Final audit and output

Before completion, verify: the canvas is vertical 9:16; the upper photograph has only been cropped, scaled, and placed; every lower color and form derives from the source; surreal intensity is low and uses only one or two relational mutations; every independent creature has exactly one pair of minimal eyes; the transition is soft without altering the photograph; and there is no text, border, watermark, or extra panel.

Return only one flattened final vertical 9:16 image after confirming that all important lower content remains visible. Do not return a duplicate source, separate upper and lower panels, alternatives, comparison sheets, analysis, prompt notes, or extra copy.
